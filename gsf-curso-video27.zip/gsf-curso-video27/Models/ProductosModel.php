<?php 
class ProductosModel extends DB
{
  public function __construct()
  {
    parent::__construct();
    
  }
}