<?php
class RolesModel extends DB
{
    public function __construct()
    {
        parent::__construct();
    }
}
