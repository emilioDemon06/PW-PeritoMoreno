# gsf-curso

# Backend Pagina WEB desde cero con PHP JAVASCRIPT ASYNC AWAIT MYSQL

TODO

<!--  -->

# VIDEO #2

1.Crear Base de datos en Mysql con phpMyAdmin
2.Crear las constante para la el archivo de conexion
3.Crear archivo de conexion a DB
4.Subir repositorio al git - Control de versiones.

<!--  -->

# VIDEO #3

1.Crear tabla de Roles
2.Crear Controlador Roles.php
3.Crear Vista y mostrarla en el navegador
4.Subir repositorio al git - Control de versiones.

<!--  -->

# VIDEO #4

1.Crear Modelo de RolesModel.php (Prueba de consulta desde model)
2.Subir repositorio al git - Control de versiones.

<!--  -->

# VIDEO #5

1.Crear clase para realizar CRUD en cualquier tabla de DB parte 1
2.Subir repositorio al git - Control de versiones.
<!--  -->

# VIDEO #6

1.Crear clase para realizar CRUD en cualquier tabla de DB parte 2
2.Mejorar el CRUD hacerlo más Dinámico
3.Subir repositorio al git - Control de versiones.
<!--  -->

# VIDEO #7

2.Corregir errores
    1a.Clase DB cambiar UPDATE a DELETE en la condicion
2.Crear clase para realizar CRUD INSERT en cualquier tabla de DB parte 3
3.Subir repositorio al git - Control de versiones.

# VIDEO #8

1.Explicando el codigo de Consultas por medio de JOIN Relacionales
2.Subir repositorio al git - Control de versiones.

# VIDEO #9

1.Crear metodo para actualizar
2.Subir repositorio al git - Control de versiones.

# VIDEO #10

1.Crear metodo para eliminar
2.Subir repositorio al git - Control de versiones.

# VIDEO #11

1.Creando constantes
2.Mejorar la carga de URL en el index mediante las constantes
3.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video11.zip

# VIDEO #12

1.Creando constantes directorios
2.Creando constantes archivos publicos
3.Creando constantes informacion del sitio
4.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video12.zip


# VIDEO #13

1.Agregando funciones a nuestra clase helpers
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video13.zip

# VIDEO #14

1.Cargando el favicon desde una funcion php
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video14.zip

# VIDEO #15

1.Tabla de usuarios
2.Respaldo de base de datos
3.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video15.zip

# VIDEO #16

1.Vista de login 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video16.zip

# VIDEO #17

1.Crear funcion para cargar el logo dinamico  
2.Agregar SITE_DESC en el meta de login 
3.Vista register 
4.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video17.zip

# VIDEO #18

1.Registrar usuario parte 1 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video18.zip

# VIDEO #19

1.Registrar usuario parte 2 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video19.zip

# VIDEO #20

1.Registrar usuario parte 3 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video20.zip

# VIDEO #21

1.Registrar usuario parte 4 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video21.zip

# VIDEO #22

1.Registrar usuario parte 5 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video22.zip

# VIDEO #23

1.Registrar usuario parte 6 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video23.zip

# VIDEO #24

1.Registrar usuario parte 7 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video24.zip

# VIDEO #25

1.Registrar usuario parte 8 -> integrando plugin alerta con noty 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video25.zip

# VIDEO #26 

1.Registrar usuario parte 9 -> validando en el js y mandando alertas 
2.Subir repositorio al git - Control de versiones.
https://github.com/luigonsa79/gsf-curso/archive/refs/tags/video26.zip

# VIDEO #27

1.Mejorar el la function esc de helper para eliminar espacios vacios con rtrim o trim 
2.Subir repositorio al git - Control de versiones.

# VIDEO #28 ^PENDIENTE^

1.Crear clase de validacion para usar en controllers
2.Subir repositorio al git - Control de versiones.

# VIDEO #29 ^PENDIENTE^

1.Validar registro en js y crear clase de helpers.js
2.Subir repositorio al git - Control de versiones.

# VIDEO #30 ^PENDIENTE^

1.Sistema de login de usuario parte 1
2.Subir repositorio al git - Control de versiones.
